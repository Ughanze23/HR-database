-- create employee table
create table employee (emp_ID varchar(8) ,Emp_Name VARCHAR(50), hire_Date DATE,Email VARCHAR(100),PRIMARY KEY (emp_ID,hire_Date));

-- create salary table
CREATE TABLE Salary (
    Salary_ID SERIAL PRIMARY KEY,
    Salary INT);
    
CREATE TABLE Education (
    Education_ID SERIAL PRIMARY KEY,
    Education_Lvl VARCHAR(50));    
    

-- create office table
CREATE TABLE Office_Locations (
    Location_ID SERIAL PRIMARY KEY,
    Location VARCHAR(50) ,City VARCHAR(50),Address VARCHAR(50), State VARCHAR(2));

-- create job_title table
CREATE TABLE Roles (Job_ID SERIAL PRIMARY KEY,
                  Job_Title VARCHAR(100));
                  
-- create Department table                  
CREATE TABLE Departments (
DEPT_ID SERIAL PRIMARY KEY, 
Dept_Name VARCHAR(50));

-- create workhistory table
CREATE TABLE Work_History (
Emp_ID VARCHAR(8) ,
Dept_ID INT REFERENCES Departments (Dept_ID),
Location_ID INT REFERENCES Office_locations (Location_ID),    
Hire_Date DATE,
Start_Date  DATE,
End_Date DATE,
Job_ID INT REFERENCES Roles (Job_ID),
Salary_ID INT REFERENCES Salary (Salary_ID),
Education_ID INT REFERENCES Education (Education_ID),
Manager_ID VARCHAR(8),    
PRIMARY KEY (Emp_ID,Start_Date)     
);

-- load data into Salary table
Insert into Salary(Salary)
Select distinct Salary from  proj_stg;


-- load data into departments table
Insert into Departments(Dept_Name)
Select distinct department_nm from  proj_stg as proj;

-- load data into Education table
Insert into Education(Education_Lvl)
Select distinct education_lvl from  proj_stg as proj;

-- load data into job_title table
Insert into Roles(Job_title)
Select distinct  job_title from  proj_stg;


-- load data office table
Insert into Office_Locations(Location ,City,Address,State)
Select distinct   location,city,address,state from  proj_stg;

-- load data into employee table
Insert into employee(emp_ID,Emp_Name,hire_Date,Email )
Select distinct   stg.Emp_ID ,stg.Emp_NM,stg.hire_dt, stg.Email from  proj_stg stg;

-- load data in work_history
Insert into
Work_History (
Emp_ID,    
Dept_ID,
Location_ID,    
Hire_Date ,
Start_Date,
End_Date,
Job_ID,Salary_ID,Education_ID,Manager_ID)
SELECT DISTINCT e.Emp_ID,dept.dept_ID,loc.Location_ID,proj.hire_dt,proj.start_dt,proj.end_dt,role.Job_ID,sal.Salary_ID,ed.education_ID,em.Emp_ID
FROM proj_stg as proj
LEFT JOIN employee as e on e.Emp_ID = proj.Emp_ID 
LEFT JOIN Office_Locations as loc on loc.location = proj.location 
LEFT jOIN roles as role ON proj.job_title = role.Job_title
LEFT JOIN departments as dept on dept.dept_name = proj.department_nm 
LEFT JOIN employee as em ON em.Emp_Name = proj.manager
LEFT JOIN Salary as sal on sal.salary = proj.salary
LEFT JOIN education as ed on ed.Education_Lvl = proj.education_lvl
; 


--Q1
-- Return a list of employees with Job Titles and Department Names 
SELECT Emp_Name,Job_title,Dept_Name
FROM employee e
JOIN work_history work on work.emp_ID = e.emp_ID
JOIN roles ON work.job_ID = roles.Job_ID
JOIN departments dept ON dept.Dept_ID = work.Dept_ID;


--Q2
-- Question 2: Insert Web Programmer as a new job title

INSERT INTO Roles(Job_title)
values ('Web Programmer');

--Question 3: Correct the job title from web programmer to web developer
UPDATE Roles
SET job_title = 'Web Developer'
WHERE job_title = 'Web Programmer';


--Question 4: Delete the job title Web Developer from the database
 DELETE FROM Roles
 WHERE job_title = 'Web Developer';
 
 
 --Question 5: How many employees are in each department?
 
 SELECT Dept_Name,COUNT(emp_ID) as no_of_employees
 FROM work_History as work
 JOIN departments dept ON dept.dept_ID = work.Dept_ID
 WHERE EXTRACT(YEar FROM end_date) = 2100
GROUP BY dept_Name;
 
 
 --Question 6: Write a query that returns current and past jobs (include employee name, job title, department, manager name, start and end date for position) for employee Toni Lembeck
 SELECT e.Emp_Name,Job_title,Dept_Name,Start_Date ,
End_Date,m.Emp_Name as Manager
FROM employee e
JOIN work_history work on work.emp_ID = e.emp_ID
JOIN roles ON work.job_ID = roles.Job_ID
JOIN departments dept ON dept.Dept_ID = work.Dept_ID
JOIN employee m on work.Manager_ID = m.emp_ID
WHERE e.Emp_Name = 'Toni Lembeck';


-- Creating a view of work history
CREATE VIEW  employee_history_view as
SELECT emp.emp_ID, emp.Emp_Name,work.Hire_Date,ed.Education_Lvl,Job_title,Salary,Dept_Name,m.Emp_Name as Manager,
work.Start_Date,work.End_Date,Location,Address,City,State
FROM employee emp
LEFT JOIN work_History work on work.emp_ID = emp.emp_ID
LEFT JOIN salary sal on sal.salary_ID = work.salary_ID
LEFT JOIN Office_Locations loc on loc.location_ID = work.location_ID
LEFT JOIN roles rol on rol.job_ID = work.job_ID
LEFT JOIN departments dept on dept.dept_id = work.dept_ID
LEFT JOIN  employee m on m.Emp_ID = work.manager_ID
LEFT JOIN education ed on ed.Education_ID = work.Education_ID;

SELECT * FROM employee_history_view;

CREATE USER NoMgr;
GRANT CONNECT ON DATABASE postgres TO NoMgr;
REVOKE SELECT ON Salary from NoMgr;


